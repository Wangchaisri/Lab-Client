var mo = require('./lib.js'); 

mo.test1();