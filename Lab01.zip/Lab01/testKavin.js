var mo = require('./kavin.js'); 
mo.test1();

