let mo = require('./gpa.js'); 
mo.gpacalu();

