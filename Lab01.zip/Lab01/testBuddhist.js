var mo = require('./buddhist.js'); 
mo.test1();

