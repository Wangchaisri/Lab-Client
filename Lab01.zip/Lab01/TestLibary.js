var mo = require('./libary.js'); 

mo.test1();