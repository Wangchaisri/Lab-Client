let mo = require('./lab2.js'); 
mo.gpacalu();

